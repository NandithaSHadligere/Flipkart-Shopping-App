export const GET_PRODUCTS_SUCCESS = 'getProductsSuccess'
export const GET_PRODUCTS_FAIL = 'getProductsFail'


export const GET_PRODUCT_DETAILS_REQUEST = 'getProductDetailsRequest'
export const GET_PRODUCT_DETAILS_SUCCESS = 'getProductDetailSuccess'
export const GET_PRODUCT_DETAILS_FAIL = 'getProductDetailFail'
export const GET_PRODUCT_DETAILS_RESET = 'getProductDetailReset'